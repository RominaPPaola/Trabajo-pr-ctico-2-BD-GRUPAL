-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-12-2023 a las 04:35:23
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `integrador_cac`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oradores`
--

CREATE TABLE `oradores` (
  `id_orador` int(11) NOT NULL,
  `nombre` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `apellido` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `mail` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tema` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Fecha_alta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `oradores`
--

INSERT INTO `oradores` (`id_orador`, `nombre`, `apellido`, `mail`, `tema`, `Fecha_alta`) VALUES
(1, 'Agustín', 'Lopez', 'alopez@hotmail.com', 'aaaa aaaaaa', '2023-12-21 00:40:44'),
(2, 'Pedro', 'Damasco', 'adam@gmail.com', 'bb bbbbbbbbb', '2023-12-21 00:41:17'),
(3, 'Ariel', 'Mendoza', 'amen@gmail.com', 'cccccccccccc', '2023-12-21 00:41:52'),
(4, 'Juan', 'Macana', 'jmacana@outlook.com', 'dd ddddddddd', '2023-12-21 00:42:29'),
(5, 'Ruben ', 'Portillo', 'rporti@outlook.com', 'eeeeeeeeeee', '2023-12-21 00:43:16'),
(6, 'Roberto', 'Ruben', 'rru@hotmail.com', 'ffffffffffffff fff', '2023-12-21 03:32:21'),
(7, 'Santiago', 'Rocha', 'srochi@gmail.com', 'ggggggg gggg', '2023-12-21 03:32:36'),
(8, 'Karen ', 'Rugero', 'kruge@gmail.com', 'hhhhhhhhhhhhh', '2023-12-21 00:45:27'),
(9, 'Silvia', 'Verdum', 'sverdum@hotmail.com', 'iiiiiiiiiiiiiii iii', '2023-12-21 03:24:42'),
(10, 'Thomas', 'Palacios', 'tpala@gmail.com', 'jjjj jjjjjjj jjjj', '2023-12-21 03:26:02');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `oradores`
--
ALTER TABLE `oradores`
  ADD PRIMARY KEY (`id_orador`),
  ADD UNIQUE KEY `mail` (`mail`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `oradores`
--
ALTER TABLE `oradores`
  MODIFY `id_orador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
